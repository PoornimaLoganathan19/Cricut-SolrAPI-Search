import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Product } from "../shared/models/product";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { DealersResponse } from "../shared/models/dealersResponse";
import { CartResponse } from "../shared/models/cartResponse";
import { AddressResponse } from "../shared/models/addressResponse";
import { CardResponse } from "../shared/models/cardResponse";
import { UserService } from "../shared/services/user.service";
import { SimpleResponse } from "../shared/models/simpleResponse";
import { CartService } from "../shared/services/cart.service";
import { Address } from "../shared/models/address";
import { Card } from "../shared/models/card";
import { mediaProperties } from "../shared/mediaProperties";
import { Location } from "@angular/common";
@Component({
  selector: "app-checkout",
  templateUrl: "./checkout.component.html",
  styleUrls: ["./checkout.component.scss"]
})
export class CheckoutComponent implements OnInit {
  billingAddressForm: FormGroup;
  paymentForm: FormGroup;
  // lat = 29.748862;
  // lng = -95.331683;
  // type = "roadmap";
  // zoom = 17;

  orderResponse: CartResponse;
  addAddressResponse: AddressResponse;
  addCardResponse: CardResponse;
  checkoutAddressResponse: SimpleResponse;
  checkoutPaymentResponse: SimpleResponse;
  cartResponse: CartResponse;
  product: Product;
  totalPrice: number;
  bookingPrice: number;
  submitted = false;
  submittedPayment = false;
  firstName: string;
  lastName: string;
  line1: string;
  line2: string;
  countryId: string;
  stateId: string;
  postalCode: string;
  cardNumber: string;
  cvv: string;
  expiryMonth: number;
  expiryYear: number;
  userId: string;
  country: string;
  state: string;
  addressId: number;
  creditCardId: number;
  dealer: DealersResponse;
  creditCard = "[0-9]{16,16}";
  expiryMonthNumber = "[0-9]{2,2}";
  expiryYearNumber = "[0-9]{4,4}";
  address: Address;
  card: Card;
  mp: any;
  currency: string;
  constructor(
    public router: Router,
    private formBuilder: FormBuilder,
    private userService: UserService,
    private cartService: CartService,
    private toastr: ToastrService,
    private location: Location
  ) {}

  ngOnInit() {
    this.mp = mediaProperties;

    this.billingAddressForm = this.formBuilder.group({
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      line1: ["", Validators.required],
      line2: ["", Validators.required],
      postalCode: ["", Validators.required],
      country: ["", Validators.required],
      state: ["", Validators.required]
    });

    this.paymentForm = this.formBuilder.group({
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      cardNumber: [
        "",
        [Validators.required, Validators.pattern(this.creditCard)]
      ],
      cvv: ["", Validators.required],
      expiryMonth: [
        "",
        [Validators.required, Validators.pattern(this.expiryMonthNumber)]
      ],
      expiryYear: [
        "",
        [Validators.required, Validators.pattern(this.expiryYearNumber)]
      ]
    });
    this.getCart();
  }

  get getFormValue() {
    return this.billingAddressForm.controls;
  }

  get getPaymentFormValue() {
    return this.paymentForm.controls;
  }
  onCountrySelected(event: any) {
    this.country = event.target.value;
    console.log(this.country);
  }
  onStateSelected(event: any) {
    this.state = event.target.value;
    console.log(this.state);
  }

  billingAddress() {
    this.submitted = true;
    if (this.billingAddressForm.invalid) {
      return;
    }
    this.firstName = this.billingAddressForm.value.firstName;
    this.lastName = this.billingAddressForm.value.lastName;
    localStorage.setItem("addressFirstName", this.firstName);
    localStorage.setItem("addressLastName", this.lastName);
    this.line1 = this.billingAddressForm.value.line1;
    this.line2 = this.billingAddressForm.value.line2;
    this.postalCode = this.billingAddressForm.value.postalCode;
    this.countryId = this.billingAddressForm.value.country;
    this.stateId = this.billingAddressForm.value.state;
    console.log(
      this.firstName,
      this.lastName,
      this.line1,
      this.line2,
      this.postalCode,
      this.countryId,
      this.stateId
    );

    this.userService
      .addAddress(
        // this.firstName,
        // this.lastName,
        this.postalCode,
        this.line1,
        this.line2,
        this.countryId,
        this.stateId
      )
      .subscribe(data => {
        this.addAddressResponse = data;
        console.log(this.addAddressResponse);
        this.addressId = this.addAddressResponse.data.id;
        console.log(this.addressId);
        this.checkoutAddress();
      });
  }
  checkoutAddress() {
    this.cartService.addAddressToCart(this.addressId).subscribe(data => {
      console.log(this.addressId);
      this.checkoutAddressResponse = data;
      console.log(this.checkoutAddressResponse);
      this.getCart();
      this.toastr.success("Address saved successfully");
    });
  }
  addCreditCard() {
    this.submittedPayment = true;
    if (this.paymentForm.invalid) {
      return;
    }
    console.log(this.userId);
    this.firstName = this.paymentForm.value.firstName;
    this.lastName = this.paymentForm.value.lastName;
    this.cardNumber = this.paymentForm.value.cardNumber;
    this.cvv = this.paymentForm.value.cvv;
    this.expiryMonth = this.paymentForm.value.expiryMonth;
    this.expiryYear = this.paymentForm.value.expiryYear;
    console.log(
      this.firstName,
      this.lastName,
      this.cardNumber,
      this.cvv,
      this.expiryMonth,
      this.expiryYear
    );
    this.userService
      .addCard(
        this.cardNumber,
        this.expiryMonth,
        this.expiryYear,
        this.cvv,
        this.firstName,
        this.lastName
      )
      .subscribe(data => {
        this.addCardResponse = data;
        console.log(this.addCardResponse);
        if (this.addCardResponse.data) {
          this.creditCardId = this.addCardResponse.data.id;
          console.log(this.creditCardId);
          this.checkoutPayment();
        } else this.toastr.error("Card already exists.");
      });
  }
  checkoutPayment() {
    this.cartService
      .addPaymentToCart(this.creditCardId, this.bookingPrice)
      .subscribe(data => {
        this.checkoutPaymentResponse = data;
        console.log(this.checkoutPaymentResponse);
        this.getCart();
        this.toastr.success("Payment saved successfully");
      });
  }
  getCart() {
    this.cartService.getCart().subscribe(data => {
      this.cartResponse = data;
      console.log(this.cartResponse);

      var colorId = this.cartResponse.data.entries.find(
        entry => entry.product.partType == "color"
      ).product.productId;
      var wheelId = this.cartResponse.data.entries.find(
        entry => entry.product.partType == "wheel"
      ).product.productId;
      var upholsteryId = this.cartResponse.data.entries.find(
        entry => entry.product.partType == "upholstery"
      ).product.productId;
      var trimId = this.cartResponse.data.entries.find(
        entry => entry.product.partType == "trim"
      ).product.productId;
      this.product = this.cartResponse.data.entries.find(
        entry => entry.product.partType == "product"
      ).product;
      this.currency = this.product.price.currency;
      this.product.url =
        this.mp.baseUrl +
        this.mp.walkaround +
        this.mp.vehicle +
        this.product.productId +
        this.mp.paint +
        colorId +
        this.mp.fabric +
        upholsteryId +
        this.mp.sa +
        wheelId +
        "," +
        trimId +
        this.mp.angle +
        this.mp.background;
      this.bookingPrice = this.cartResponse.data.totalPrice * 0.01;
      if (this.cartResponse.data.shippingAddress)
        this.address = this.cartResponse.data.shippingAddress;
      if (this.cartResponse.data.paymentInfos)
        this.card = this.cartResponse.data.paymentInfos[0].creditCard;
      if (this.address) {
        this.billingAddressForm = this.formBuilder.group({
          firstName: [
            localStorage.getItem("addressFirstName"),
            Validators.required
          ],
          lastName: [
            localStorage.getItem("addressLastName"),
            Validators.required
          ],
          line1: [this.address.line1, Validators.required],
          line2: [this.address.line2, Validators.required],
          postalCode: [this.address.postalCode, Validators.required],
          country: [this.address.country.countryId, Validators.required],
          state: [this.address.state.stateId, Validators.required]
        });
      }
      if (this.card) {
        this.paymentForm = this.formBuilder.group({
          firstName: [this.card.firstName, Validators.required],
          lastName: [this.card.lastName, Validators.required],
          cardNumber: [
            this.card.cardNumber,
            [Validators.required, Validators.pattern(this.creditCard)]
          ],
          cvv: [this.cvv, Validators.required],
          expiryMonth: [
            this.expiryMonth,
            [Validators.required, Validators.pattern(this.expiryMonthNumber)]
          ],
          expiryYear: [
            this.expiryYear,
            [Validators.required, Validators.pattern(this.expiryYearNumber)]
          ]
        });
      }
    });
  }
  showCart() {
    document.getElementById("cartPopup").click();
  }
}
